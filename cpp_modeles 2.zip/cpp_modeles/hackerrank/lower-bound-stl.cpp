#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

int main() {
    int size, q_size;
    vector<int> vec;

    cin >> size;

    for (int i = 0; i < size; i++){
        int x = 0;
        cin >> x;
        vec.push_back(x);
    }
    cin >> q_size;
    for (int i = 0; i < q_size; i++){
        int x;
        cin >> x;
		vector<int>::iterator low = lower_bound(vec.begin(), vec.end(), x);
		if (x == *low)
			cout << "Yes " << (low - vec.begin() + 1) << endl;
		else
			cout << "No " << (low - vec.begin() + 1) << endl;
			
    }
    return 0;
}
