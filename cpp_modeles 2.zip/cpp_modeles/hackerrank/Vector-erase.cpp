#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;


int main() {
    int size, e_size;
    vector<int> v;
    int erase1, erase2;

    cin >> size;
    cin.ignore();
    for (int i = 0; i < size; i++)
    {
        int x;
        cin >> x;
        v.push_back(x);
        cin.ignore();
    }
    cin >> e_size;
    cin.ignore();
    cin >> erase1;
    cin >> erase2;

    v.erase(v.begin() + e_size - 1);
    v.erase(v.begin() + erase1 - 1, v.begin() + erase2 - 1);

    cout << v.size() << endl;
    for (int i = 0; i < v.size(); i++)
        cout << v[i] << " ";
    return 0;
}
