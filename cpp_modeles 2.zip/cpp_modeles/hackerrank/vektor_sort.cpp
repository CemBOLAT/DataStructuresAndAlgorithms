#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
    vector<int> v;
    int n;

    cin >> n;

    for (int i = 0; i < n; ++i) {
        int x;
        cin >> x;
		cin.ignore();
        v.push_back(x);
    }

    sort(v.begin(), v.end());

    for (int i = 0; i < n; ++i) {
        cout << v[i] << " ";
    }

    return 0;
}
