#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

int	space_count(string str)
{
	int count = 0;

	for (int i = 0; i < str.length(); i++)
	{
		if (str[i] == ' ')
			count++;
	}
	return count;
}

string  **f_q_parser(string *query, int q)
{
    string  **query_parser;
	int		tilde, dot;

    query_parser = new string*[q];
	for (int i = 0; i < q; i++){
		query_parser[i] = new string[3];
		tilde = query[i].find('~');
		dot = query[i].find('.');
		query_parser[i][0] = query[i].substr(0, tilde);
		query_parser[i][1] = query[i].substr(tilde + 1, dot - tilde - 1);
		query_parser[i][2] = query[i].substr(dot + 1, query[i].length() - dot - 1);
	}
    return query_parser;
}

string **f_tag_parser(string *tags, int n)
{
	string  **tags_parser;

	tags_parser = new string*[n];
	for (int i = 0; i < n; i++){
		tags_parser[i] = new string[space_count(tags[i]) + 1];
		for (int j = 0; j < space_count(tags[i]) + 1; j++)
		{
			int k = 0;
			while (tags[i][k] != ' ')
			{
				if (tags[i][k] != '<' || tags[i][k] != '>' || tags[i][k] != '/')
					tags_parser[i][j] += tags[i][k];
				k++;
			}
		}
	}
	return tags_parser;

}

int main() {
    int     n, q;
    string  *tags, *query;
    string  **query_parser, **tags_parser;

    cin >> n >> q;
    tags = new string[n];
    query = new string[q];
	cin.ignore();
    for (int i = 0; i < n; i++)
	{
		getline(cin, tags[i]);
	}
	for (int i = 0; i < q; i++)
	{
        getline(cin, query[i]);

	}
	tags_parser = f_tag_parser(tags, n);
	query_parser = f_q_parser(query, q);
	for (int i = 0; i < q; i++)
	{
		for (int j = 0; j < n; j++)
		{
			if (query_parser[i][0] == tags_parser[j][0])
			{
				if (query_parser[i][1] == tags_parser[j][1])
				{
					if (query_parser[i][2] == tags_parser[j][2])
					{
						cout << tags[j] << endl;
					}
				}
			}
		}
	}
	
    return 0;
}
