#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <set>
#include <algorithm>
using namespace std;

int main() {
    int q_num;
    set<int> arr;

    cin >> q_num;
    for (int i = 0; i < q_num; i++) {
        int type, num;
        cin >> type >> num;

        if (type == 1)
            arr.insert(num);
        else if (type == 2 && arr.find(num) != arr.end()) {
            arr.erase(num);
        }
        else if (type == 3) {
            if (arr.find(num) == arr.end())
                cout << "No" << endl;
            else
                cout << "Yes" << endl;
        }
    }

    return 0;
}
