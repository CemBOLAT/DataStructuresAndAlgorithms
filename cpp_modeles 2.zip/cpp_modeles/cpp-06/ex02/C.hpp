#pragma once

#include "Base.hpp"

class C : public Base{};
