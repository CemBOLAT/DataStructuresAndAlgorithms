#pragma once

#include <iostream>

bool	scientificNotation(std::string const &str);
int		printer(char c, int i, float f, double d);
bool	charConverter(std::string const &obj);
bool	intConverter(std::string const &obj);
bool	errorConverter(std::string const &obj);
bool	floatConverter(std::string const &obj);
bool	doubleConverter(std::string const &obj);
int		printer(int i, float f, double d);
int		printer(void);
