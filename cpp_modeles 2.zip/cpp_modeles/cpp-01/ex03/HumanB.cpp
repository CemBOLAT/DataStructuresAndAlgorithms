/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanB.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/29 23:21:08 by cbolat            #+#    #+#             */
/*   Updated: 2023/09/18 15:20:19 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./Weapon.hpp"
#include "./HumanB.hpp"
#include "./HumanA.hpp"

HumanB::~HumanB(){
	std::cout << this->name << " is dead. " << std::endl;
}

void	HumanB::attack(void)
{
	if (HumanA::getIsArmed() != 0){
		std::cout << this->name << " cannot attack because HumanA is armed" << std::endl;
		return;
	}
	std::cout << this->name << " attacks with their " << this->weapon->getType() << std::endl;
	return ;
}

HumanB::HumanB(std::string name) : name(name)
{
	std::cout << name << " named HumanB created ! " << std::endl;
	this->name = name;
}

void HumanB::setWeapon(Weapon &weapon)
{
	if (HumanA::getIsArmed() != 0){
		std::cout << this->name << " cannot armed because HumanA is armed" << std::endl;
	}
	else
		this->weapon = &weapon;
}
