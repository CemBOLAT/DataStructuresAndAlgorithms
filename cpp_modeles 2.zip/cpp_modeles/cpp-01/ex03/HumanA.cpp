/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanA.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/29 22:13:24 by cbolat            #+#    #+#             */
/*   Updated: 2023/09/18 15:11:55 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Weapon.hpp"
#include "HumanA.hpp"

int HumanA::isArmed = 0;

HumanA::HumanA(std::string name, Weapon &weapon) : name(name), weapon(&weapon)
{
	std::cout << name << " named HumanA created ! " << std::endl;
	HumanA::isArmed++;
}

void	HumanA::attack(void)
{
	std::cout << this->name << " attacks with their " << this->weapon->getType() << std::endl;
}


HumanA::~HumanA()
{
	std::cout << this->name << " died" << std::endl;
	HumanA::isArmed--;
}

int	HumanA::getIsArmed(void)
{
	return (HumanA::isArmed);
}
