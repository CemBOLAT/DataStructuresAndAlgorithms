/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanA.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: cbolat <cbolat@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/29 22:04:19 by cbolat            #+#    #+#             */
/*   Updated: 2023/09/18 14:49:43 by cbolat           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUMANA_HPP
# define HUMANA_HPP

#include "./Weapon.hpp"

class HumanA
{
	private:
		std::string	name;
		Weapon		*weapon;
		static int isArmed;
	public:
		HumanA(std::string name, Weapon &weapon);

		~HumanA();

		static int	getIsArmed(void);
		void		attack(void);

};
#endif
