#include "main.hpp"
using namespace GTU;
#include <iostream>

int gtuset::gtusets() {
	std::cout << "gtuset" << std::endl;
	return 4;
}
