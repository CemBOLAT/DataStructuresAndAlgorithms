#include <iostream>

using namespace std;

void	refer(int &a){
	a = 5;
	cout << a << endl;
}

void	point(int *a){
	*a = 6;
	cout << *a << endl;
}

int main(){
	int a = 4;

	refer(a);

	cout << a << endl;

	poia);

	cout << a << endl;


}

