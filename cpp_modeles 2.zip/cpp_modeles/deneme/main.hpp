#ifndef MAIN_HPP
#define MAIN_HPP

#include <iostream>
#include <string>

// why we use virtual keyword?
// https://stackoverflow.com/questions/2391679/why-do-we-need-virtual-functions-in-c

class Math{
	public :
		Math(){
			std::cout << "Math constructor" << std::endl;
		}
		~Math(){
			std::cout << "Math destructor" << std::endl;
		}
		virtual int findAlan(int a, int b){
			return 2;
		}
		virtual int findCevre(int a, int b){
			return 5;
		}
};

class Kare : private Math { // firstly
	public :
		Kare(){
			kenar = 0;
			std::cout << "Kare constructor" << std::endl;
		}
		Kare(int kenar){
			kenar = kenar;
		}
		void setKenar(int kenar){
			kenar = kenar;
		}
		int getKenar(){
			return kenar;
		}
		int findAlan(int a, int b) override {
			return a * b;
		}
		int findCevre(int a, int b) override{
			return 2 * (a + b);
		}
	private :
		int kenar;
};

class Daire : public Math {
	public :
		Daire(){
			yaricap = 0;
		}
		Daire(int yaricap){
			yaricap = yaricap;
		}
		void setYaricap(int yaricap){
			yaricap = yaricap;
		}
		int getYaricap(){
			return yaricap;
		}
		int findAlan(int yaricap, int pi) override {
			return pi * yaricap * yaricap;
		}
		int findCevre(int yaricap, int pi) override{
			return 2 * pi * yaricap;
		}
	private :
		int yaricap;
};

#endif
