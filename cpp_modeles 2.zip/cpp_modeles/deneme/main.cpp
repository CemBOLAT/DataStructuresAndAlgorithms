#include "./main.hpp"

void	printMath(Math *math){
	std::cout << "Alan : " << math->findAlan(5, 5) << std::endl;
	std::cout << "Cevre : " << math->findCevre(5, 5) << std::endl;
	std::cout << "----------------------------" << std::endl;
}

int main(){
	Kare kare(5);
	Daire daire(5);
	// why just math constructor is called?
	// because we are using pointer to base class
	Math *math = new Math();

	//printMath(&kare);
	//printMath(&daire);
	return 0;
}
