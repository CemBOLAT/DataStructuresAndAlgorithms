#include "main.hpp"

using namespace GTU;

int main() {
	gtuset gtus;
	gtus.gtusets();
	return 0;
}
