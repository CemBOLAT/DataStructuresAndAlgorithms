#pragma once

namespace GTU {
	class gtuset {
	public:
		int gtusets();
	};
}
